pynsxv
======

PyNSXv is a high level python based library and CLI tool to control NSX
for vSphere
